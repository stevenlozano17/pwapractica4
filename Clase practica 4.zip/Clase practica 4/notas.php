<?php
require 'inc/config.php';
require 'inc/helpers.php';
if (!is_teacher()) { header('Location: index.php'); exit; }
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'] ?? null;
    $asignatura_id = $_POST['asignatura_id'];
    $usuario_id = $_POST['usuario_id'];
    $parcial = $_POST['parcial'];
    $teoria = $_POST['teoria'] ?: null;
    $practica = $_POST['practica'] ?: null;
    if ($id) {
        $stmt = $pdo->prepare('UPDATE notas SET asignatura_id=?, usuario_id=?, parcial=?, teoria=?, practica=?, usuario_id_actualizacion=?, fecha_actualizacion=? WHERE id=?');
        $stmt->execute([$asignatura_id,$usuario_id,$parcial,$teoria,$practica,$_SESSION['user']['id'], now_date(), $id]);
    } else {
        $stmt = $pdo->prepare('INSERT INTO notas (asignatura_id, usuario_id, parcial, teoria, practica, usuario_id_creacion, fecha_creacion) VALUES (?,?,?,?,?,?,?)');
        $stmt->execute([$asignatura_id,$usuario_id,$parcial,$teoria,$practica,$_SESSION['user']['id'], now_date()]);
    }
    header('Location: notas.php'); exit;
}
$stmt = $pdo->query('SELECT n.*, u.nombre as estudiante, a.nombre as asignatura FROM notas n JOIN usuarios u ON u.id = n.usuario_id JOIN asignaturas a ON a.id = n.asignatura_id ORDER BY n.id DESC');
$notas = $stmt->fetchAll();
$est = $pdo->query('SELECT id,nombre FROM usuarios WHERE rol=2')->fetchAll();
$asig = $pdo->query('SELECT id,nombre FROM asignaturas')->fetchAll();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Gestionar Notas</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-light">
<div class="container mt-4">
  <div class="card p-3">
    <h4>Notas</h4>
    <form method="post" class="row g-2">
      <input type="hidden" name="id" value="">
      <div class="col-md-4">
        <label class="form-label">Estudiante</label>
        <select name="usuario_id" class="form-select"><?php foreach($est as $e) echo "<option value='{$e['id']}'>".htmlspecialchars($e['nombre'])."</option>"; ?></select>
      </div>
      <div class="col-md-4">
        <label class="form-label">Asignatura</label>
        <select name="asignatura_id" class="form-select"><?php foreach($asig as $a) echo "<option value='{$a['id']}'>".htmlspecialchars($a['nombre'])."</option>"; ?></select>
      </div>
      <div class="col-md-2">
        <label class="form-label">Parcial</label>
        <input name="parcial" class="form-control" required>
      </div>
      <div class="col-md-1">
        <label class="form-label">Teoría</label>
        <input name="teoria" class="form-control">
      </div>
      <div class="col-md-1">
        <label class="form-label">Práctica</label>
        <input name="practica" class="form-control">
      </div>
      <div class="col-12">
        <button class="btn btn-primary mt-2" type="submit">Guardar</button>
      </div>
    </form>

    <hr>
    <h5>Listado</h5>
    <table class="table table-striped">
      <thead><tr><th>ID</th><th>Estudiante</th><th>Asignatura</th><th>Parcial</th><th>Teoría</th><th>Práctica</th></tr></thead>
      <tbody>
      <?php foreach($notas as $n): ?>
      <tr>
        <td><?= $n['id'] ?></td>
        <td><?= htmlspecialchars($n['estudiante']) ?></td>
        <td><?= htmlspecialchars($n['asignatura']) ?></td>
        <td><?= htmlspecialchars($n['parcial']) ?></td>
        <td><?= htmlspecialchars($n['teoria']) ?></td>
        <td><?= htmlspecialchars($n['practica']) ?></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <a class="btn btn-secondary" href="dashboard_teacher.php">Volver</a>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
