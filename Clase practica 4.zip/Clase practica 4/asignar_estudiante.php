<?php
require 'inc/config.php';
require 'inc/helpers.php';
if (!is_teacher()) { header('Location: index.php'); exit; }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lugar = $_POST['lugar_id'];
    $asig = $_POST['asignatura_id'];
    $usuario = $_POST['usuario_id'];
    $stmt = $pdo->prepare('INSERT INTO asignaturas_estudiante (lugar_id, asignatura_id, usuario_id, usuario_id_creacion, fecha_creacion) VALUES (?,?,?,?,?)');
    $stmt->execute([$lugar, $asig, $usuario, $_SESSION['user']['id'], now_date()]);
    header('Location: asignar_estudiante.php'); exit;
}
$lugares = $pdo->query('SELECT id,nombre FROM lugares')->fetchAll();
$asig = $pdo->query('SELECT id,nombre FROM asignaturas')->fetchAll();
$est = $pdo->query('SELECT id,nombre FROM usuarios WHERE rol=2')->fetchAll();
$asignados = $pdo->query('SELECT ae.*, u.nombre as estudiante, a.nombre as asignatura, l.nombre as lugar FROM asignaturas_estudiante ae JOIN usuarios u ON u.id=ae.usuario_id JOIN asignaturas a ON a.id=ae.asignatura_id JOIN lugares l ON l.id=ae.lugar_id ORDER BY ae.id DESC')->fetchAll();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Asignar Estudiante</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-light">
<div class="container mt-4">
  <div class="card p-3">
    <h4>Asignar Estudiante</h4>
    <form method="post" class="row g-2">
      <div class="col-md-4">
        <select name="lugar_id" class="form-select"><?php foreach($lugares as $l) echo "<option value='{$l['id']}'>".htmlspecialchars($l['nombre'])."</option>"; ?></select>
      </div>
      <div class="col-md-4">
        <select name="asignatura_id" class="form-select"><?php foreach($asig as $a) echo "<option value='{$a['id']}'>".htmlspecialchars($a['nombre'])."</option>"; ?></select>
      </div>
      <div class="col-md-4">
        <select name="usuario_id" class="form-select"><?php foreach($est as $e) echo "<option value='{$e['id']}'>".htmlspecialchars($e['nombre'])."</option>"; ?></select>
      </div>
      <div class="col-12"><button class="btn btn-primary mt-2" type="submit">Asignar</button></div>
    </form>

    <hr>
    <h5>Asignaciones</h5>
    <table class="table table-striped">
      <thead><tr><th>ID</th><th>Estudiante</th><th>Asignatura</th><th>Lugar</th></tr></thead>
      <tbody>
      <?php foreach($asignados as $a): ?>
      <tr><td><?= $a['id'] ?></td><td><?= htmlspecialchars($a['estudiante']) ?></td><td><?= htmlspecialchars($a['asignatura']) ?></td><td><?= htmlspecialchars($a['lugar']) ?></td></tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <a class="btn btn-secondary" href="dashboard_teacher.php">Volver</a>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
