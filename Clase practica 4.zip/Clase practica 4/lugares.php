<?php
require 'inc/config.php';
require 'inc/helpers.php';
if (!is_teacher()) { header('Location: index.php'); exit; }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    if (!empty($_POST['id'])) {
        $stmt = $pdo->prepare('UPDATE lugares SET nombre=?, usuario_id_actualizacion=?, fecha_actualizacion=? WHERE id=?');
        $stmt->execute([$nombre, $_SESSION['user']['id'], now_date(), $_POST['id']]);
    } else {
        $stmt = $pdo->prepare('INSERT INTO lugares (nombre, usuario_id_creacion, fecha_creacion) VALUES (?,?,?)');
        $stmt->execute([$nombre, $_SESSION['user']['id'], now_date()]);
    }
    header('Location: lugares.php'); exit;
}
$l = $pdo->query('SELECT * FROM lugares')->fetchAll();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Lugares</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-light">
<div class="container mt-4">
  <div class="card p-3">
    <h4>Lugares</h4>
    <form method="post" class="row g-2">
      <input type="hidden" name="id" value="">
      <div class="col-md-8">
        <input name="nombre" class="form-control" placeholder="Nombre" required>
      </div>
      <div class="col-md-4">
        <button class="btn btn-primary w-100" type="submit">Guardar</button>
      </div>
    </form>
    <hr>
    <table class="table table-striped">
      <thead><tr><th>ID</th><th>Nombre</th></tr></thead>
      <tbody>
      <?php foreach($l as $i): ?>
      <tr><td><?= $i['id'] ?></td><td><?= htmlspecialchars($i['nombre']) ?></td></tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <a class="btn btn-secondary" href="dashboard_teacher.php">Volver</a>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
