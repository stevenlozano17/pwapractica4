<?php
function is_logged() { return isset($_SESSION['user']); }
function is_teacher() { return is_logged() && $_SESSION['user']['rol'] == 1; }
function is_student() { return is_logged() && $_SESSION['user']['rol'] == 2; }
?>