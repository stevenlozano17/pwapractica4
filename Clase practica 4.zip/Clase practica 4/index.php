<?php
require 'inc/config.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'] ?? '';
    $pass = $_POST['contrasena'] ?? '';

    $stmt = $pdo->prepare('SELECT * FROM usuarios WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    if ($user) {
        if (password_verify($pass, $user['contrasena'])) {
            $_SESSION['user'] = $user;
            if ($user['rol'] == 1) header('Location: dashboard_teacher.php');
            else header('Location: dashboard_student.php');
            exit;
        }
    }
    $error = 'Credenciales inválidas';
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Login - Sistema de Calificaciones</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-light">
  <div class="container">
    <div class="row justify-content-center mt-5">
      <div class="col-md-5">
        <div class="card shadow-sm">
          <div class="card-body">
            <h3 class="card-title mb-3">Iniciar sesión</h3>
            <?php if(!empty($error)) echo "<div class='alert alert-danger'>".htmlspecialchars($error)."</div>"; ?>
            <form method="post">
              <div class="mb-3">
                <label class="form-label">Email</label>
                <input class="form-control" type="email" name="email" required>
              </div>
              <div class="mb-3">
                <label class="form-label">Contraseña</label>
                <input class="form-control" type="password" name="contrasena" required>
              </div>
              <button class="btn btn-primary w-100" type="submit">Entrar</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
