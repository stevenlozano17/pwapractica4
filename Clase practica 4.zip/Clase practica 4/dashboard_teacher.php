<?php
require 'inc/config.php';
require 'inc/helpers.php';
if (!is_teacher()) { header('Location: index.php'); exit; }
$user = $_SESSION['user'];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Docente - Panel</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Calificaciones</a>
    <div class="d-flex">
      <span class="navbar-text me-3">Bienvenido, <?=htmlspecialchars($user['nombre'])?></span>
      <a class="btn btn-outline-light btn-sm" href="logout.php">Salir</a>
    </div>
  </div>
</nav>
<div class="container mt-4">
  <div class="row g-3">
    <div class="col-md-3">
      <div class="list-group">
        <a href="lugares.php" class="list-group-item list-group-item-action">Gestionar Lugares</a>
        <a href="asignaturas.php" class="list-group-item list-group-item-action">Gestionar Asignaturas</a>
        <a href="estudiantes.php" class="list-group-item list-group-item-action">Gestionar Estudiantes</a>
        <a href="asignar_estudiante.php" class="list-group-item list-group-item-action">Asignar Estudiantes</a>
        <a href="notas.php" class="list-group-item list-group-item-action">Gestionar Notas</a>
      </div>
    </div>
    <div class="col-md-9">
      <div class="card p-3">
        <h4>Panel Docente</h4>
        <p>Usa las opciones del menú para administrar el sistema.</p>
      </div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
