<?php
require 'inc/config.php';
require 'inc/helpers.php';
if (!is_teacher()) { header('Location: index.php'); exit; }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $pass = $_POST['contrasena'];
    if (!empty($_POST['id'])) {
        $stmt = $pdo->prepare('UPDATE usuarios SET nombre=?, email=?, usuario_id_actualizacion=?, fecha_actualizacion=? WHERE id=?');
        $stmt->execute([$nombre, $email, $_SESSION['user']['id'], now_date(), $_POST['id']]);
    } else {
        $hash = password_hash($pass, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare('INSERT INTO usuarios (nombre,email,rol,contrasena,usuario_id_creacion,fecha_creacion) VALUES (?,?,?,?,?,?)');
        $stmt->execute([$nombre,$email,2,$hash,$_SESSION['user']['id'], now_date()]);
    }
    header('Location: estudiantes.php'); exit;
}
$est = $pdo->query('SELECT * FROM usuarios WHERE rol=2')->fetchAll();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Estudiantes</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-light">
<div class="container mt-4">
  <div class="card p-3">
    <h4>Estudiantes</h4>
    <form method="post" class="row g-2">
      <input type="hidden" name="id" value="">
      <div class="col-md-4"><input name="nombre" class="form-control" placeholder="Nombre" required></div>
      <div class="col-md-4"><input name="email" class="form-control" placeholder="Email" type="email" required></div>
      <div class="col-md-4"><input name="contrasena" class="form-control" placeholder="Contraseña" type="password" required></div>
      <div class="col-12"><button class="btn btn-primary mt-2" type="submit">Guardar</button></div>
    </form>
    <hr>
    <table class="table table-striped">
      <thead><tr><th>ID</th><th>Nombre</th><th>Email</th></tr></thead>
      <tbody>
      <?php foreach($est as $e): ?>
      <tr><td><?= $e['id'] ?></td><td><?= htmlspecialchars($e['nombre']) ?></td><td><?= htmlspecialchars($e['email']) ?></td></tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <a class="btn btn-secondary" href="dashboard_teacher.php">Volver</a>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
