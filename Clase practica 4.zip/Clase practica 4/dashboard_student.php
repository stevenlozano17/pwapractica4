<?php
require 'inc/config.php';
require 'inc/helpers.php';
if (!is_student()) { header('Location: index.php'); exit; }
header('Location: ver_notas.php');
exit;
