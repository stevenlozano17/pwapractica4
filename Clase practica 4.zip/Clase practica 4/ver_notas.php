<?php
require 'inc/config.php';
require 'inc/helpers.php';
if (!is_student()) { header('Location: index.php'); exit; }
$uid = $_SESSION['user']['id'];
$sql = "SELECT n.*, a.nombre as asignatura
FROM notas n
JOIN asignaturas a ON a.id = n.asignatura_id
WHERE n.usuario_id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$uid]);
$notas = $stmt->fetchAll();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Mis notas</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Calificaciones</a>
    <div class="d-flex">
      <span class="navbar-text me-3">Bienvenido, <?=htmlspecialchars($_SESSION['user']['nombre'])?></span>
      <a class="btn btn-outline-light btn-sm" href="logout.php">Salir</a>
    </div>
  </div>
</nav>
<div class="container mt-4">
  <div class="card p-3">
    <h4>Mis Notas</h4>
    <table class="table table-striped">
      <thead><tr><th>Asignatura</th><th>Parcial</th><th>Teoría</th><th>Práctica</th><th>Promedio</th></tr></thead>
      <tbody>
      <?php foreach($notas as $n):
        $prom = null;
        if ($n['teoria'] !== null || $n['practica'] !== null) {
          $t = $n['teoria'] ?? 0; $p = $n['practica'] ?? 0; $prom = round((($t + $p)/2),2);
        }
      ?>
      <tr>
        <td><?=htmlspecialchars($n['asignatura'])?></td>
        <td><?=htmlspecialchars($n['parcial'])?></td>
        <td><?=htmlspecialchars($n['teoria'])?></td>
        <td><?=htmlspecialchars($n['practica'])?></td>
        <td><?=htmlspecialchars($prom)?></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <a class="btn btn-secondary" href="logout.php">Salir</a>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
